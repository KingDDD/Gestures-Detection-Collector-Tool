# Prerequisites
mldb

# Automatic Setup
Run the setup.py environment initialization script

	./setup.py

# Manual Setup
After Cloning this Repo into a project directory:
Install the latest pip version (may require sudo)

	pip install --upgrade pip

Install Virtual Environment (may also require sudo)

	pip install virtualenv

Create and Name the Virtual Environment (try "venv")

	virtualenv venv

Source this Environment to activate it

	source ./venv/bin/activate

Install python module requirements

	pip install -r requirements.txt

# Execution
To Run the Gesture GUI, have the virutal environment active and navigate to the scripts directory

	cd gestures/data-collection/scripts/

Launch the GUI with

	./GUI.py
