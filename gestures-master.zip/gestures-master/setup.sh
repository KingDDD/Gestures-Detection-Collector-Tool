#!/usr/bin/env bash

echo "

		Virtual Environment will be set up in:
"
pwd
export MY_PATH=$PWD
sudo pip install --upgrade pip
pip install virtualenv
virtualenv venv
source ./venv/bin/activate
sudo apt-get -y install python-dev
sudo apt-get -y install libjpeg8-dev
pip install -r requirements.txt
cd data-collection/scripts


echo "

		Setup Complete	
		"

exec bash
