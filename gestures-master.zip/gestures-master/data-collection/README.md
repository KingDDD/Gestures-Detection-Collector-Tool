Data Collection Directory

This directory is home to the configuration files that define the Gesture dictionary for the collection.  
