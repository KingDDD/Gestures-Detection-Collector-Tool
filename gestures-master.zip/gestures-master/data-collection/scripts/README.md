This Directory is home to the Gesture GUI

To launch the GUI, activate the virtualenv

	./GUI.py
